"""
Full-duplex voice chat: microphone -> LiteLLM -> Gemini 3.1 Flash Live -> speakers.

Audio format facts that matter (the usual source of silent failures):
  * INPUT  to the model: PCM16, 16 kHz, mono, little-endian
  * OUTPUT from the model: PCM16, 24 kHz, mono, little-endian
Sending 24 kHz input produces chipmunk audio or no transcription at all.

Run:
    pip install -r requirements.txt
    python mic_stream.py
Ctrl-C to stop.
"""

import asyncio
import base64
import json
import os
import queue
import sys

import numpy as np
import sounddevice as sd
import websockets
from dotenv import load_dotenv

load_dotenv()

BASE_URL = os.getenv("LITELLM_BASE_URL", "ws://localhost:4000")
API_KEY = os.getenv("LITELLM_API_KEY", "")
MODEL = os.getenv("LITELLM_MODEL", "gemini-3.1-live")
VOICE = os.getenv("GEMINI_VOICE", "aoede")

INPUT_SAMPLE_RATE = 16_000
OUTPUT_SAMPLE_RATE = 24_000
BLOCK_SIZE = 800  # 50 ms at 16 kHz

URL = f"{BASE_URL.rstrip('/')}/v1/realtime?model={MODEL}"

TEXT_EVENTS = {
    "response.text.delta",
    "response.output_text.delta",
    "response.audio_transcript.delta",
    "response.output_audio_transcript.delta",
}
AUDIO_EVENTS = {"response.audio.delta", "response.output_audio.delta"}


def connect(url: str, headers: dict):
    """websockets >= 14 renamed extra_headers -> additional_headers."""
    try:
        return websockets.connect(url, additional_headers=headers, max_size=None)
    except TypeError:
        return websockets.connect(url, extra_headers=headers, max_size=None)


async def main() -> None:
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "api-key": API_KEY,
        "OpenAI-Beta": "realtime=v1",
    }

    mic_q: queue.Queue[bytes] = queue.Queue()
    playback_q: queue.Queue[bytes] = queue.Queue()
    loop = asyncio.get_running_loop()

    def mic_callback(indata, frames, time_info, status):
        if status:
            print(f"[mic] {status}", file=sys.stderr)
        mic_q.put(bytes(indata))

    residual = bytearray()  # partial chunk carried between callbacks

    def speaker_callback(outdata, frames, time_info, status):
        needed = frames * 2  # bytes, PCM16 mono
        while len(residual) < needed:
            try:
                residual.extend(playback_q.get_nowait())
            except queue.Empty:
                break
        if len(residual) < needed:
            buf = bytes(residual) + b"\x00" * (needed - len(residual))
            residual.clear()
        else:
            buf = bytes(residual[:needed])
            del residual[:needed]
        outdata[:] = np.frombuffer(buf, dtype=np.int16).reshape(-1, 1)

    print(f"Connecting to {URL} ...")
    async with connect(URL, headers) as ws:
        print("Connected. Start talking (Ctrl-C to quit).\n")

        await ws.send(json.dumps({
            "type": "session.update",
            "session": {
                "modalities": ["audio"],
                "voice": VOICE,
                "instructions": "You are a helpful voice assistant. Keep answers brief and natural.",
                "input_audio_format": "pcm16",
                "output_audio_format": "pcm16",
                # Let the server decide when the user stopped speaking.
                "turn_detection": {
                    "type": "server_vad",
                    "threshold": 0.5,
                    "silence_duration_ms": 500,
                },
            },
        }))

        async def pump_mic() -> None:
            while True:
                chunk = await loop.run_in_executor(None, mic_q.get)
                await ws.send(json.dumps({
                    "type": "input_audio_buffer.append",
                    "audio": base64.b64encode(chunk).decode("utf-8"),
                }))

        async def pump_events() -> None:
            async for raw in ws:
                event = json.loads(raw)
                etype = event.get("type", "")

                if etype in AUDIO_EVENTS:
                    b64 = event.get("delta") or ""
                    if b64:
                        playback_q.put(base64.b64decode(b64))

                elif etype in TEXT_EVENTS:
                    print(event.get("delta", ""), end="", flush=True)

                elif etype == "input_audio_buffer.speech_started":
                    # Barge-in: user interrupted, drop queued model audio.
                    with playback_q.mutex:
                        playback_q.queue.clear()
                    residual.clear()
                    print("\n[you] ", end="", flush=True)

                elif etype == "error":
                    print(f"\n[server error] {event.get('error', event)}", flush=True)

        with sd.RawInputStream(
            samplerate=INPUT_SAMPLE_RATE,
            blocksize=BLOCK_SIZE,
            dtype="int16",
            channels=1,
            callback=mic_callback,
        ), sd.OutputStream(
            samplerate=OUTPUT_SAMPLE_RATE,
            blocksize=1024,
            dtype="int16",
            channels=1,
            callback=speaker_callback,
        ):
            await asyncio.gather(pump_mic(), pump_events())


if __name__ == "__main__":
    if not API_KEY:
        sys.exit("LITELLM_API_KEY is not set. Copy .env.example to .env and fill it in.")
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nStopped.")
