"""
Gemini 3.1 Flash Live via LiteLLM's OpenAI-compatible /v1/realtime WebSocket.

Sends one text turn, receives native audio + transcript, writes response.wav.

Run:
    cp .env.example .env   # fill in LITELLM_API_KEY
    pip install -r requirements.txt
    python gemini_live_client.py "Tell me a three word joke."
"""

import asyncio
import base64
import json
import os
import sys
import wave

import websockets
from dotenv import load_dotenv

load_dotenv()

BASE_URL = os.getenv("LITELLM_BASE_URL", "ws://localhost:4000")
API_KEY = os.getenv("LITELLM_API_KEY", "")
MODEL = os.getenv("LITELLM_MODEL", "gemini-3.1-live")
VOICE = os.getenv("GEMINI_VOICE", "aoede")  # puck | charon | kore | fenrir | aoede
OUT_WAV = os.getenv("OUTPUT_WAV", "response.wav")

# Gemini Live emits 24 kHz PCM16 mono. Input from a mic must be 16 kHz (see mic_stream.py).
OUTPUT_SAMPLE_RATE = 24_000

URL = f"{BASE_URL.rstrip('/')}/v1/realtime?model={MODEL}"

# Transcript deltas arrive under a few different event names depending on the
# LiteLLM version and whether it emits GA or beta OpenAI realtime event shapes.
TEXT_EVENTS = {
    "response.text.delta",
    "response.output_text.delta",
    "response.audio_transcript.delta",
    "response.output_audio_transcript.delta",
}
AUDIO_EVENTS = {
    "response.audio.delta",
    "response.output_audio.delta",
}
DONE_EVENTS = {"response.done", "response.completed"}


def connect(url: str, headers: dict):
    """websockets >= 14 renamed extra_headers -> additional_headers."""
    try:
        return websockets.connect(url, additional_headers=headers, max_size=None)
    except TypeError:
        return websockets.connect(url, extra_headers=headers, max_size=None)


def write_wav(path: str, pcm: bytes, sample_rate: int = OUTPUT_SAMPLE_RATE) -> None:
    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)  # PCM16
        wf.setframerate(sample_rate)
        wf.writeframes(pcm)


async def run(prompt: str) -> None:
    headers = {
        # LiteLLM accepts either header. Bearer is the OpenAI-SDK-compatible one.
        "Authorization": f"Bearer {API_KEY}",
        "api-key": API_KEY,
        "OpenAI-Beta": "realtime=v1",
    }

    print(f"Connecting to {URL} ...")
    async with connect(URL, headers) as ws:
        print("Connected.")

        audio_chunks: list[bytes] = []
        done = asyncio.Event()

        async def receive() -> None:
            try:
                async for raw in ws:
                    event = json.loads(raw)
                    etype = event.get("type", "")

                    if etype in TEXT_EVENTS:
                        print(event.get("delta", ""), end="", flush=True)

                    elif etype in AUDIO_EVENTS:
                        b64 = event.get("delta") or ""
                        if b64:
                            audio_chunks.append(base64.b64decode(b64))

                    elif etype == "error":
                        err = event.get("error", event)
                        print(f"\n[server error] {err}", flush=True)
                        done.set()

                    elif etype in DONE_EVENTS:
                        print("\n[turn complete]", flush=True)
                        done.set()

                    else:
                        print(f"\n[event] {etype}", flush=True)
            except websockets.exceptions.ConnectionClosed:
                print("\nConnection closed by server.")
            finally:
                done.set()

        async def send() -> None:
            # ── Session config ────────────────────────────────────────────
            # Gemini 3.1 Flash Live supports ONE response modality per session.
            # ["text", "audio"] is rejected/coerced -- pick audio for voice.
            await ws.send(json.dumps({
                "type": "session.update",
                "session": {
                    "modalities": ["audio"],
                    "voice": VOICE,
                    "instructions": "You are a helpful voice assistant. Keep answers brief.",
                    "output_audio_format": "pcm16",
                    "input_audio_format": "pcm16",
                    "turn_detection": {"type": "server_vad"},
                },
            }))
            await asyncio.sleep(0.5)

            # ── User turn ─────────────────────────────────────────────────
            # NOTE: on gemini-3.1-flash-live-preview, conversation.item.create
            # (client content) is only supported for seeding the FIRST turn.
            # For subsequent turns stream realtime input instead -- see mic_stream.py.
            await ws.send(json.dumps({
                "type": "conversation.item.create",
                "item": {
                    "type": "message",
                    "role": "user",
                    "content": [{"type": "input_text", "text": prompt}],
                },
            }))
            await ws.send(json.dumps({"type": "response.create"}))
            print(f"Prompt sent: {prompt!r}\n")

        receiver = asyncio.create_task(receive())
        await send()

        try:
            await asyncio.wait_for(done.wait(), timeout=60)
        except asyncio.TimeoutError:
            print("\n[timed out waiting for response.done]")
        receiver.cancel()

        if audio_chunks:
            pcm = b"".join(audio_chunks)
            write_wav(OUT_WAV, pcm)
            seconds = len(pcm) / (OUTPUT_SAMPLE_RATE * 2)
            print(f"Wrote {OUT_WAV} ({seconds:.1f}s, {len(pcm):,} bytes PCM16 @ 24kHz)")
        else:
            print("No audio received.")


if __name__ == "__main__":
    if not API_KEY:
        sys.exit("LITELLM_API_KEY is not set. Copy .env.example to .env and fill it in.")
    text = " ".join(sys.argv[1:]) or "Hello! Tell me a three word joke out loud."
    asyncio.run(run(text))
