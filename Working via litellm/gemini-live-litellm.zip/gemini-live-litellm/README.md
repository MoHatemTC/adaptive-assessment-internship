# Gemini 3.1 Flash Live via LiteLLM Realtime

Connects to `gemini-3.1-flash-live-preview` through LiteLLM's OpenAI-compatible
`/v1/realtime` WebSocket, so you keep one gateway, one key, and one spend log.

```
config.yaml             LiteLLM proxy config (the mode: realtime flag is the important bit)
gemini_live_client.py   One text turn in -> transcript + response.wav out
mic_stream.py           Full-duplex mic <-> speaker voice chat with barge-in
.env.example            Copy to .env and fill in your LiteLLM virtual key
requirements.txt
```

## Quick start

```bash
pip install -r requirements.txt
cp .env.example .env          # set LITELLM_API_KEY

# if you run the proxy from YAML:
export GEMINI_API_KEY=...
export LITELLM_MASTER_KEY=sk-...
litellm --config config.yaml --port 4000

python gemini_live_client.py "Tell me a three word joke."
python mic_stream.py
```

---

## What to change in the LiteLLM admin UI

If your proxy has `STORE_MODEL_IN_DB=True` you can do all of this in the UI with no
redeploy. Models loaded from `config.yaml` show a **config** badge and are **not**
editable from the UI — those have to change in YAML.

### 1. Add the deployment

**Models + Endpoints → Add Model**

| Field | Value |
|---|---|
| Provider | Google AI Studio |
| LiteLLM Model Name | `gemini/gemini-3.1-flash-live-preview` |
| Public Model Name | `gemini-3.1-live` |
| API Key | your `GEMINI_API_KEY` |
| **Mode** (Advanced Settings) | **`realtime`** |

**The Mode field is the one that actually matters.** It writes
`model_info.mode = "realtime"`. Without it the deployment is only routable on
`/v1/chat/completions`, and the WebSocket upgrade to `/v1/realtime?model=...`
fails with a 400 / "model not found" before Gemini is ever contacted.

If the dropdown has no `realtime` option on your version, add it via the API instead:

```bash
curl -X POST "$LITELLM_URL/model/new" \
  -H "Authorization: Bearer $LITELLM_MASTER_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model_name": "gemini-3.1-live",
    "litellm_params": {
      "model": "gemini/gemini-3.1-flash-live-preview",
      "api_key": "os.environ/GEMINI_API_KEY"
    },
    "model_info": { "mode": "realtime" }
  }'
```

To confirm it took, open the model's detail page → **Raw JSON** tab and check that
`model_info.mode` is `realtime`.

### 2. Issue a virtual key with access to it

**Virtual Keys → Create New Key** → grant `gemini-3.1-live` under allowed models.
Put that `sk-...` in `.env` as `LITELLM_API_KEY`. The realtime endpoint authenticates
like every other route — an unauthenticated WebSocket upgrade is rejected.

### 3. Check pricing is mapped

**Models + Endpoints → All Models →** find the row and look at the cost columns.
Realtime billing is per-second of audio, not per-token. If `gemini-3.1-flash-live-preview`
predates your LiteLLM version's cost map, the row shows `$0.00` and sessions log as free.
Two fixes: bump LiteLLM, or set the cost overrides on the model's **Edit Settings** page.

### 4. Timeouts, if you terminate TLS in front of the proxy

Realtime sessions are long-lived WebSockets. Anything in front of LiteLLM needs to
allow the upgrade and stop idle-killing it. For Nginx:

```nginx
location /v1/realtime {
    proxy_pass http://127.0.0.1:4000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_read_timeout 3600s;
    proxy_send_timeout 3600s;
    proxy_buffering off;
}
```

Then switch `LITELLM_BASE_URL` to `wss://your-host` in `.env`.

### 5. Version floor

Gemini realtime over `/v1/realtime` landed in LiteLLM **v1.70.1**. Anything older
won't have the translation layer at all. Gemini 3 support is much newer than that —
if the model 404s at the provider, upgrade LiteLLM before debugging your client.

---

## Fixes applied to the original snippet

| # | Original | Problem | Fixed to |
|---|---|---|---|
| 1 | config had no `model_info` | Model never routable on `/v1/realtime` | added `model_info: mode: realtime` |
| 2 | no auth header | Proxy rejects the upgrade | `Authorization: Bearer` + `api-key` |
| 3 | `extra_headers=` | Renamed in websockets ≥ 14 | try `additional_headers`, fall back |
| 4 | `modalities: ["text","audio"]` | 3.1 Flash Live allows **one** modality per session | `["audio"]` |
| 5 | "input must be 24 kHz" | Input is **16 kHz**; 24 kHz is the *output* rate | 16 kHz in, 24 kHz out |
| 6 | only `response.audio.delta` handled | GA event names differ by version | handles `response.output_audio.delta` and the transcript variants too |
| 7 | `asyncio.create_task(ws.send(...))` from a sync def | Fire-and-forget, no backpressure, no event loop guarantee | proper `await` inside an async pump |
| 8 | no session teardown | Script hangs after the turn | waits on `response.done`, then writes WAV |

## One behavioural gotcha on 3.1

On `gemini-3.1-flash-live-preview`, `conversation.item.create` (client content) is
only supported for **seeding the first turn**. After the model's first response,
send realtime input instead — audio via `input_audio_buffer.append`, as `mic_stream.py`
does. A text-only multi-turn loop built on repeated `conversation.item.create` calls
worked on 2.5 and will misbehave here.
