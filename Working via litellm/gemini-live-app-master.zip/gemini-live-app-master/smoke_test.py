"""End-to-end check of the LiteLLM -> Gemini Live path, without a browser.

    docker compose run --rm gemini-live python smoke_test.py
"""

from __future__ import annotations

import os
import queue
import sys
import time

from audio_utils import duration_seconds
from live_client import OUTPUT_SAMPLE_RATE, LiveSession, realtime_url

PROMPT = "What is the capital of Japan?"
# Deliberately arbitrary: it can only show up if the instructions really landed.
INSTRUCTIONS = "End every single reply with the word BANANA."


def main() -> int:
    base_url = os.getenv("LITELLM_BASE_URL", "")
    api_key = os.getenv("LITELLM_API_KEY", "")
    model = os.getenv("LITELLM_MODEL", "gemini/gemini-3.1-flash-live-preview")

    if not base_url or not api_key:
        print("LITELLM_BASE_URL and LITELLM_API_KEY must be set.", file=sys.stderr)
        return 2

    print(f"→ {realtime_url(base_url, model)}")

    session = LiveSession(
        base_url=base_url,
        api_key=api_key,
        model=model,
        instructions=INSTRUCTIONS,
        voice="Puck",
    )

    if not session.start():
        print(f"✗ connect failed: {session.error}", file=sys.stderr)
        return 1
    print("✓ session.created + instructions primed")

    session.send_text(PROMPT)

    audio = bytearray()
    text: list[str] = []
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        try:
            event = session.events.get(timeout=0.25)
        except queue.Empty:
            continue
        kind = event["type"]
        if kind == "audio":
            audio += event["data"]
        elif kind == "text":
            text.append(event["text"])
        elif kind == "done":
            break
        elif kind in ("error", "closed"):
            print(f"✗ {event.get('message', 'session closed')}", file=sys.stderr)
            return 1
    else:
        print("✗ timed out waiting for the model's turn", file=sys.stderr)
        return 1

    session.close()

    transcript = "".join(text).strip()
    print(f"✓ transcript: {transcript or '(none)'}")
    print(f"✓ audio: {len(audio)} bytes ({duration_seconds(audio, OUTPUT_SAMPLE_RATE):.1f}s @ {OUTPUT_SAMPLE_RATE} Hz)")

    ok = True
    if not audio:
        print("✗ no audio returned", file=sys.stderr)
        ok = False
    if "banana" not in transcript.lower():
        print("✗ system instructions did not reach the model", file=sys.stderr)
        ok = False
    else:
        print("✓ system instructions applied")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
