# Gemini Live · Streamlit + LiteLLM

A small Streamlit app for holding a spoken conversation with
`gemini/gemini-3.1-flash-live-preview`, routed through a LiteLLM proxy.

You speak into your browser mic, the model answers with generated speech, and
both sides are transcribed into the chat log. Typing works too.

## Run it

```bash
cp .env.example .env      # fill in your LiteLLM URL + key
docker compose up --build -d
```

Open <http://localhost:8501>, check the sidebar values, press **Connect**, then
record a message.

> Use `localhost`, not a LAN IP. Browsers only expose the microphone on a secure
> context, and `http://localhost` qualifies while `http://192.168.x.x` does not.
> The compose file binds the port to loopback for that reason.

Check connectivity without a browser:

```bash
docker compose run --rm gemini-live python smoke_test.py
```

It connects, sends a text turn, and verifies that audio, a transcript, and the
system instructions all came back.

## How it works

See [ARCHITECTURE.md](ARCHITECTURE.md) for the threading model, the captured
wire protocol, and the OpenAI-Realtime ↔ Gemini translation table.

LiteLLM's `/v1/realtime` websocket speaks the **OpenAI Realtime** event protocol
and translates to and from Gemini's `BidiGenerateContent` protocol, so the app
never talks to Google directly:

```
browser mic ──wav──▶ ffmpeg ──pcm16/24k──▶ input_audio_buffer.append
                                            │
                                            ▼
        wss://<litellm>/v1/realtime?model=gemini/gemini-3.1-flash-live-preview
                                            │
        response.output_audio.delta ◀───────┘
                     │
                     ▼
              pcm16/24k ──▶ WAV ──▶ st.audio(autoplay)
```

- [live_client.py](live_client.py) holds the websocket open in a background
  thread with its own asyncio loop, because Streamlit re-runs the script on
  every interaction and cannot keep a connection in the script body. The whole
  chat is one Gemini session, so the model remembers earlier turns.
- [audio_utils.py](audio_utils.py) converts the browser recording to mono PCM16
  with ffmpeg, and wraps the model's PCM output back into a WAV for playback.
  There is a stdlib-only fallback if ffmpeg is missing.
- [app.py](app.py) is the UI: sidebar config, chat transcript, push-to-talk.

Each recording is sent as one turn: audio chunks followed by
`input_audio_buffer.commit`, which LiteLLM maps to Gemini's `audioStreamEnd` so
the turn closes immediately instead of waiting for voice-activity detection to
time out on trailing silence.

## Proxy quirks worth knowing

Both of these were verified against a live proxy, not assumed:

- **System instructions are sent as an opening conversation turn**, not via
  `session.update`. Gemini accepts session config only in its first `setup`
  frame; some LiteLLM versions emit that frame themselves and drop the client's,
  which silently discards `instructions`. An opening turn works on every
  version, and the model's acknowledgement is swallowed before it reaches the
  UI. See `LiveSession._prime_instructions`.
- **Voice and temperature ride in that same dropped frame**, so they may have no
  effect. On the proxy this was built against they don't — a deliberately bogus
  voice name connects without complaint. They are kept under *Advanced* because
  they do work against proxies that forward client session config.

## Microphone sample rate

LiteLLM tags outgoing audio as `audio/pcm;rate=24000`, so the app resamples the
mic to 24 kHz to match — feeding 16 kHz audio under a 24 kHz tag makes the model
hear you shifted. Round-tripping generated speech back through the mic path
transcribed cleanly at 24000 and dropped words at 16000, so 24000 is the
default. The **Advanced** panel exposes 16000 for proxies that tag differently.

## Limits

- Push-to-talk, not open-mic. Streamlit re-runs its script per interaction and
  has no continuous audio stream, so you record a message and send it. The
  underlying session stays open, so turn-to-turn latency is just the model.
- You cannot interrupt the model mid-reply; the turn plays to completion.
