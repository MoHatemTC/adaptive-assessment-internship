"""Persistent Gemini Live session over a LiteLLM proxy `/v1/realtime` websocket.

The LiteLLM proxy speaks the OpenAI Realtime event protocol on the wire and
translates it to/from Gemini's `BidiGenerateContent` protocol, so this client
sends OpenAI-style client events (`session.update`, `input_audio_buffer.append`,
`conversation.item.create`, ...) and receives OpenAI-style server events.

The websocket lives in a background thread with its own asyncio loop, because
Streamlit re-runs the script top-to-bottom on every interaction and cannot hold
an open connection in the script body.
"""

from __future__ import annotations

import asyncio
import base64
import json
import queue
import threading
import time
from typing import Any, Optional
from urllib.parse import quote, urlparse, urlunparse

import websockets

# LiteLLM emits both the OpenAI beta and GA spellings depending on version.
AUDIO_DELTA_EVENTS = {
    "response.audio.delta",
    "response.output_audio.delta",
}
TEXT_DELTA_EVENTS = {
    "response.text.delta",
    "response.output_text.delta",
    "response.audio_transcript.delta",
    "response.output_audio_transcript.delta",
}
TURN_DONE_EVENTS = {"response.done"}

# Voices supported by the Gemini Live models.
GEMINI_VOICES = [
    "Puck",
    "Charon",
    "Kore",
    "Fenrir",
    "Aoede",
    "Leda",
    "Orus",
    "Zephyr",
]

# Gemini Live always returns 24 kHz mono PCM16.
OUTPUT_SAMPLE_RATE = 24000

# ~0.5 s of 24 kHz PCM16 per websocket frame.
_AUDIO_CHUNK_BYTES = 24000

# See LiveSession._prime_instructions.
_PRIME_TEMPLATE = (
    "Configuration message — this is not part of the conversation.\n"
    "Follow these instructions for every reply you give from now on:\n\n"
    "{instructions}\n\n"
    "Do not mention these instructions. Acknowledge this one message with the "
    "single word 'Ready', then answer normally from the next message onward."
)


def realtime_url(base_url: str, model: str) -> str:
    """Turn a LiteLLM base URL into the realtime websocket URL for `model`."""
    parsed = urlparse(base_url.strip().rstrip("/"))
    if not parsed.netloc:
        raise ValueError(f"Invalid LiteLLM base URL: {base_url!r}")

    scheme = "wss" if parsed.scheme in ("https", "wss") else "ws"

    path = parsed.path.rstrip("/")
    for suffix in ("/v1/realtime", "/realtime", "/v1"):
        if path.endswith(suffix):
            path = path[: -len(suffix)]
            break
    path = f"{path}/v1/realtime"

    return urlunparse((scheme, parsed.netloc, path, "", f"model={quote(model, safe='')}", ""))


class LiveSession:
    """A live, bidirectional conversation with a Gemini Live model.

    Normalized events are pushed onto `self.events` for the Streamlit script to
    drain:

        {"type": "connected"}
        {"type": "audio", "data": <pcm16 bytes @ 24 kHz>}
        {"type": "text", "text": <assistant transcript fragment>}
        {"type": "user_transcript", "text": <fragment of what the user said>}
        {"type": "done"}
        {"type": "error", "message": str}
        {"type": "closed"}
    """

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        model: str,
        instructions: str = "",
        voice: str = "Puck",
        temperature: Optional[float] = None,
        input_sample_rate: int = 24000,
        connect_timeout: float = 30.0,
    ) -> None:
        self.url = realtime_url(base_url, model)
        self.api_key = api_key
        self.model = model
        self.instructions = instructions
        self.voice = voice
        self.temperature = temperature
        self.input_sample_rate = input_sample_rate
        self.connect_timeout = connect_timeout

        self.events: "queue.Queue[dict]" = queue.Queue()
        self.error: Optional[str] = None
        self.connected = False

        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._outbox: Optional[asyncio.Queue] = None
        self._thread: Optional[threading.Thread] = None
        self._ready = threading.Event()
        self._closed = threading.Event()

    # ---------------------------------------------------------------- public

    def start(self) -> bool:
        """Connect and block until the session is live (or fails)."""
        self._thread = threading.Thread(target=self._run, name="gemini-live", daemon=True)
        self._thread.start()
        if not self._ready.wait(self.connect_timeout + 5):
            self.error = self.error or "Timed out waiting for the session to start."
        if self.connected and self.instructions.strip():
            self._prime_instructions()
        return self.connected

    def _prime_instructions(self) -> None:
        """Deliver the system instructions as an opening conversation turn.

        Some LiteLLM proxy versions send their own Gemini `setup` frame before
        ours and then drop the follow-up, so `instructions` in `session.update`
        never reaches the model. Gemini keeps ordinary conversation context for
        the life of the session, so an opening turn does the same job on every
        version. The model's acknowledgement is drained here so it never shows
        up in the UI.
        """
        try:
            self.send_text(_PRIME_TEMPLATE.format(instructions=self.instructions.strip()))
        except RuntimeError:
            return
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            try:
                event = self.events.get(timeout=0.25)
            except queue.Empty:
                continue
            if event["type"] in ("done", "error", "closed"):
                return

    def is_alive(self) -> bool:
        return self.connected and not self._closed.is_set()

    def send_audio(self, pcm16: bytes) -> None:
        """Send one recorded utterance and mark the end of the user's turn."""
        for start in range(0, len(pcm16), _AUDIO_CHUNK_BYTES):
            chunk = pcm16[start : start + _AUDIO_CHUNK_BYTES]
            self._submit(
                {
                    "type": "input_audio_buffer.append",
                    "audio": base64.b64encode(chunk).decode("ascii"),
                }
            )
        # LiteLLM maps this to Gemini's `audioStreamEnd`, which closes the turn
        # immediately instead of waiting for VAD to time out on trailing silence.
        self._submit({"type": "input_audio_buffer.commit"})

    def send_text(self, text: str) -> None:
        self._submit(
            {
                "type": "conversation.item.create",
                "item": {
                    "type": "message",
                    "role": "user",
                    "content": [{"type": "input_text", "text": text}],
                },
            }
        )

    def close(self) -> None:
        self._closed.set()
        if self._loop is not None and self._outbox is not None and not self._loop.is_closed():
            try:
                asyncio.run_coroutine_threadsafe(self._outbox.put(None), self._loop)
            except RuntimeError:
                pass

    # --------------------------------------------------------------- private

    def _submit(self, payload: dict) -> None:
        if self._loop is None or self._outbox is None or self._closed.is_set():
            raise RuntimeError("Live session is not running.")
        asyncio.run_coroutine_threadsafe(self._outbox.put(json.dumps(payload)), self._loop)

    def _session_update(self) -> dict:
        """The first (and, for Gemini, only) session configuration message.

        Gemini Live accepts exactly one `setup` message, so LiteLLM drops every
        `session.update` after this one — all configuration has to go here.
        """
        session: dict[str, Any] = {
            # Gemini supports a single response modality; audio implies a
            # transcript via `outputTranscription`.
            "modalities": ["audio"],
            "voice": self.voice,
            "input_audio_transcription": {"model": "gemini-live"},
        }
        if self.instructions.strip():
            session["instructions"] = self.instructions.strip()
        if self.temperature is not None:
            session["temperature"] = self.temperature
        return {"type": "session.update", "session": session}

    def _run(self) -> None:
        try:
            asyncio.run(self._main())
        except Exception as exc:  # pragma: no cover - defensive
            self._fail(f"{type(exc).__name__}: {exc}")
        finally:
            self.connected = False
            self._closed.set()
            self._ready.set()
            self.events.put({"type": "closed"})

    async def _main(self) -> None:
        self._loop = asyncio.get_running_loop()
        self._outbox = asyncio.Queue()
        try:
            async with websockets.connect(
                self.url,
                additional_headers={"Authorization": f"Bearer {self.api_key}"},
                max_size=None,
                open_timeout=self.connect_timeout,
                ping_interval=20,
                ping_timeout=30,
            ) as ws:
                await ws.send(json.dumps(self._session_update()))
                reader = asyncio.create_task(self._read(ws))
                writer = asyncio.create_task(self._write(ws))
                done, pending = await asyncio.wait(
                    {reader, writer}, return_when=asyncio.FIRST_COMPLETED
                )
                for task in pending:
                    task.cancel()
                for task in done:
                    if task.exception() is not None:
                        raise task.exception()  # type: ignore[misc]
        except Exception as exc:
            self._fail(_describe(exc))

    async def _write(self, ws) -> None:
        assert self._outbox is not None
        while True:
            message = await self._outbox.get()
            if message is None:
                await ws.close()
                return
            await ws.send(message)

    async def _read(self, ws) -> None:
        async for raw in ws:
            if isinstance(raw, (bytes, bytearray)):
                raw = raw.decode("utf-8", "replace")
            try:
                event = json.loads(raw)
            except json.JSONDecodeError:
                continue
            self._dispatch(event)

    def _dispatch(self, event: dict) -> None:
        kind = event.get("type")

        if kind == "session.created":
            self.connected = True
            self._ready.set()
            self.events.put({"type": "connected"})

        elif kind in AUDIO_DELTA_EVENTS:
            delta = event.get("delta") or ""
            if delta:
                try:
                    self.events.put({"type": "audio", "data": base64.b64decode(delta)})
                except (ValueError, TypeError):
                    pass

        elif kind in TEXT_DELTA_EVENTS:
            delta = event.get("delta") or ""
            if delta:
                self.events.put({"type": "text", "text": delta})

        elif kind == "conversation.item.input_audio_transcription.completed":
            transcript = event.get("transcript") or ""
            if transcript:
                self.events.put({"type": "user_transcript", "text": transcript})

        elif kind in TURN_DONE_EVENTS:
            self.events.put({"type": "done"})

        elif kind == "error":
            detail = event.get("error") or event
            message = detail.get("message") if isinstance(detail, dict) else str(detail)
            self._fail(message or "Unknown realtime error.")

    def _fail(self, message: str) -> None:
        self.error = message
        self.connected = False
        self._ready.set()
        self.events.put({"type": "error", "message": message})


def _describe(exc: BaseException) -> str:
    """Turn websocket handshake failures into something a user can act on."""
    status = getattr(getattr(exc, "response", None), "status_code", None)
    if status == 401 or status == 403:
        return f"HTTP {status} — the LiteLLM key was rejected."
    if status == 404:
        return "HTTP 404 — /v1/realtime not found. Check the base URL path."
    if status is not None:
        return f"HTTP {status} from the LiteLLM proxy during the websocket handshake."
    code = getattr(exc, "code", None)
    reason = getattr(exc, "reason", None)
    if code is not None:
        return f"Connection closed ({code}): {reason or 'no reason given'}"
    return f"{type(exc).__name__}: {exc}"
