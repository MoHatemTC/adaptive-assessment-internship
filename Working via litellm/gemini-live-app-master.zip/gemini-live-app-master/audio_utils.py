"""Audio conversion between the browser's recording and Gemini's PCM16 stream."""

from __future__ import annotations

import array
import io
import shutil
import subprocess
import wave


class AudioError(RuntimeError):
    pass


def to_pcm16(data: bytes, sample_rate: int) -> bytes:
    """Decode arbitrary recorded audio into mono little-endian PCM16."""
    if not data:
        raise AudioError("Empty recording.")

    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg:
        proc = subprocess.run(
            [
                ffmpeg, "-hide_banner", "-loglevel", "error",
                "-i", "pipe:0",
                "-f", "s16le", "-acodec", "pcm_s16le",
                "-ac", "1", "-ar", str(sample_rate),
                "pipe:1",
            ],
            input=data,
            capture_output=True,
        )
        if proc.returncode == 0 and proc.stdout:
            return proc.stdout
        detail = proc.stderr.decode("utf-8", "replace").strip()
        # Fall through to the stdlib path; ffmpeg only fails here on odd inputs.
        try:
            return _wav_to_pcm16(data, sample_rate)
        except AudioError:
            raise AudioError(f"ffmpeg could not decode the recording: {detail or 'unknown error'}")

    return _wav_to_pcm16(data, sample_rate)


def pcm16_to_wav(pcm: bytes, sample_rate: int) -> bytes:
    """Wrap raw PCM16 in a WAV container so a browser can play it."""
    buffer = io.BytesIO()
    with wave.open(buffer, "wb") as out:
        out.setnchannels(1)
        out.setsampwidth(2)
        out.setframerate(sample_rate)
        out.writeframes(pcm)
    return buffer.getvalue()


def duration_seconds(pcm: bytes, sample_rate: int) -> float:
    return len(pcm) / 2 / sample_rate


def _wav_to_pcm16(data: bytes, sample_rate: int) -> bytes:
    """Pure-stdlib fallback: parse a WAV, downmix to mono, resample linearly."""
    try:
        with wave.open(io.BytesIO(data), "rb") as src:
            channels = src.getnchannels()
            width = src.getsampwidth()
            rate = src.getframerate()
            frames = src.readframes(src.getnframes())
    except (wave.Error, EOFError) as exc:
        raise AudioError(f"Not a readable WAV file ({exc}); install ffmpeg for other formats.")

    if width != 2:
        raise AudioError(f"Unsupported sample width: {width * 8}-bit. Install ffmpeg.")

    samples = array.array("h")
    samples.frombytes(frames)
    if samples.itemsize != 2:  # pragma: no cover - platform guard
        raise AudioError("Unexpected platform sample size.")

    if channels > 1:
        samples = _downmix(samples, channels)
    if rate != sample_rate:
        samples = _resample(samples, rate, sample_rate)

    return samples.tobytes()


def _downmix(samples: "array.array[int]", channels: int) -> "array.array[int]":
    mono = array.array("h", bytes(2 * (len(samples) // channels)))
    for i in range(len(mono)):
        base = i * channels
        mono[i] = sum(samples[base : base + channels]) // channels
    return mono


def _resample(samples: "array.array[int]", src_rate: int, dst_rate: int) -> "array.array[int]":
    if not samples:
        return samples
    count = max(1, round(len(samples) * dst_rate / src_rate))
    out = array.array("h", bytes(2 * count))
    step = (len(samples) - 1) / count if count > 1 else 0
    for i in range(count):
        position = i * step
        left = int(position)
        right = min(left + 1, len(samples) - 1)
        frac = position - left
        out[i] = int(samples[left] + (samples[right] - samples[left]) * frac)
    return out
