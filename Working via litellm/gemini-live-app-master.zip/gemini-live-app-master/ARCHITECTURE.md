# Architecture & wire protocol

Everything below was captured from a live session against
`https://learner-os.sprints.ai/litellm` with
`gemini/gemini-3.1-flash-live-preview`, not taken from documentation.

## 1. Components

```mermaid
flowchart LR
    subgraph browser["Browser (localhost:8501)"]
        mic["st.audio_input<br/>mic → WAV"]
        spk["st.audio<br/>autoplay"]
    end

    subgraph container["Docker container"]
        subgraph st["Streamlit script thread<br/>(re-runs on every interaction)"]
            app["app.py<br/>UI + turn assembly"]
            au["audio_utils.py<br/>ffmpeg transcode"]
        end
        subgraph bg["Background thread (asyncio)"]
            lc["live_client.py<br/>LiveSession"]
        end
    end

    proxy["LiteLLM proxy<br/>/v1/realtime"]
    gem["Gemini Live API<br/>BidiGenerateContent"]

    mic --> app --> au --> lc
    lc -- "queue.Queue" --> app --> spk
    lc <-- "wss · OpenAI Realtime events" --> proxy
    proxy <-- "wss · Gemini protocol" --> gem
```

Three processes' worth of state, in one container:

| Layer | Lives in | Lifetime |
|---|---|---|
| UI + chat log | `st.session_state` | Streamlit browser session |
| Websocket + asyncio loop | background thread | from **Connect** to **Disconnect** |
| Conversation memory | Gemini, server-side | one `session.created` → socket close |

## 2. Why a background thread

Streamlit re-runs `app.py` top to bottom on every widget interaction. A
websocket opened in the script body would die on the next rerun, so each turn
would need a fresh connection — and a fresh connection means a fresh Gemini
session with no memory of earlier turns.

`LiveSession` therefore owns a thread running its own `asyncio` loop:

```
main thread                          background thread
───────────                          ─────────────────
LiveSession.start() ───spawn───▶     asyncio.run(_main())
                                       ├─ websockets.connect(...)
                                       ├─ send session.update
                                       ├─ task: _read(ws)  ─┐
                                       └─ task: _write(ws) ─┘

send_audio(pcm)
  └─ run_coroutine_threadsafe ──▶     _outbox: asyncio.Queue ──▶ ws.send()

collect_turn()
  └─ events.get(timeout) ◀──────      events: queue.Queue ◀── _dispatch()
```

Two queues, one per direction. `asyncio.Queue` outbound (crossed from the main
thread with `run_coroutine_threadsafe`), plain `queue.Queue` inbound (drained
from the main thread with a timeout). No `st.*` call is ever made from the
background thread, so Streamlit's script-run context is never touched.

## 3. Connection

```
wss://learner-os.sprints.ai/litellm/v1/realtime?model=gemini%2Fgemini-3.1-flash-live-preview
Authorization: Bearer sk-...
```

The model goes in the **query string**, auth in a **handshake header**. The path
is the LiteLLM base URL with `/v1/realtime` appended — note this deployment is
mounted under a `/litellm` prefix, which `realtime_url()` preserves.

`gemini/gemini-3.1-flash-live-preview` resolves through the proxy's `gemini/*`
wildcard route.

## 4. Turn lifecycle

```mermaid
sequenceDiagram
    participant A as app.py
    participant L as LiveSession
    participant P as LiteLLM
    participant G as Gemini

    A->>L: start()
    L->>P: session.update
    P->>G: setup
    G-->>P: setupComplete
    P-->>L: session.created
    L->>P: conversation.item.create (instructions prime)
    Note over L: acknowledgement drained, never shown

    A->>L: send_audio(pcm16)
    loop ~0.5 s chunks
        L->>P: input_audio_buffer.append
        P->>G: realtimeInput.audio
    end
    L->>P: input_audio_buffer.commit
    P->>G: realtimeInput.audioStreamEnd

    G-->>P: serverContent.inputTranscription
    P-->>L: conversation.item.input_audio_transcription.completed
    G-->>P: serverContent.modelTurn (inlineData)
    P-->>L: response.output_audio.delta ×N
    G-->>P: serverContent.outputTranscription
    P-->>L: response.output_audio_transcript.delta ×N
    G-->>P: serverContent.turnComplete
    P-->>L: response.done
    L-->>A: {"type":"done"}
```

## 5. Client → server frames

The four frames this app actually sends, verbatim:

```jsonc
// 1. session config — must be the first frame
{"type":"session.update","session":{
  "modalities":["audio"],
  "voice":"Puck",
  "input_audio_transcription":{"model":"gemini-live"},
  "instructions":"Be brief."}}

// 2. a text turn
{"type":"conversation.item.create","item":{
  "type":"message","role":"user",
  "content":[{"type":"input_text","text":"Name three colours."}]}}

// 3. an audio turn — repeated, ~0.5 s of base64 PCM16 each
{"type":"input_audio_buffer.append","audio":"<32000 b64 chars>"}

// 4. end of the user's turn
{"type":"input_audio_buffer.commit"}
```

## 6. Server → client frames

One captured text turn produced 43 events:

| Event | Count | Used for |
|---|---|---|
| `response.created` | 1 | — |
| `response.output_item.added` | 1 | — |
| `conversation.item.added` | 1 | — |
| `response.content_part.added` | 1 | — |
| `response.output_audio_transcript.delta` | 8 | assistant transcript |
| `response.output_audio.delta` | 28 | **audio payload** |
| `response.output_audio.done` | 1 | — |
| `response.content_part.done` | 1 | — |
| `response.output_item.done` | 1 | — |
| `response.done` | 1 | **turn boundary** |

An audio turn adds one `conversation.item.input_audio_transcription.completed`
carrying what the model heard you say.

Shapes, trimmed:

```jsonc
{"type":"session.created","session":{"id":"211a9291-…","modalities":["audio"],
 "model":"gemini-3.1-flash-live-preview"},"event_id":"79464cc7-…"}

{"type":"response.output_audio.delta","delta":"<base64 PCM16 @ 24 kHz>",
 "item_id":"item_a5e9…","response_id":"resp_6e23…","content_index":0,"output_index":0}

{"type":"response.output_audio_transcript.delta","delta":"Blue, red,",
 "transcript":"Blue, red,","item_id":"item_a5e9…","response_id":"resp_6e23…"}

{"type":"conversation.item.input_audio_transcription.completed",
 "transcript":"Blue, red, and yellow. Are you thinking of a specific project?",
 "item_id":"item_f48f…","content_index":0}

{"type":"response.done","response":{"id":"resp_6e23…","status":"completed",
 "conversation_id":"conv_e01f…","modalities":["audio"],"usage":{…}}}
```

`delta` is the **increment**; the client appends. The sibling `transcript` field
is LiteLLM's addition and carries the same value.

This proxy emits the **GA** event spellings (`response.output_audio.delta`).
Older LiteLLM versions emit the **beta** spellings (`response.audio.delta`), so
`live_client.py` accepts both via `AUDIO_DELTA_EVENTS` / `TEXT_DELTA_EVENTS`.

## 7. What LiteLLM translates

The proxy is a protocol bridge — the app never sees Gemini's own schema:

| Client sends (OpenAI Realtime) | Proxy sends (Gemini) |
|---|---|
| `session.update` *(first only)* | `setup` |
| `session.update` *(subsequent)* | **dropped** |
| `input_audio_buffer.append` | `realtimeInput.audio` |
| `input_audio_buffer.commit` | `realtimeInput.audioStreamEnd` |
| `conversation.item.create` (text) | `clientContent.turns` + `turnComplete:true` |
| `conversation.item.create` (tool result) | `toolResponse.functionResponses` |
| `response.create` | **dropped** — Gemini replies on its own |

| Gemini sends | Client receives |
|---|---|
| `setupComplete` | `session.created` |
| `serverContent.modelTurn` → `inlineData` | `response.output_audio.delta` |
| `serverContent.modelTurn` → `text` | `response.output_text.delta` |
| `serverContent.outputTranscription` | `response.output_audio_transcript.delta` |
| `serverContent.inputTranscription` | `conversation.item.input_audio_transcription.completed` |
| `serverContent.generationComplete` | `response.output_audio.done` |
| `serverContent.turnComplete` / `interrupted` | `response.done` |

Because `response.create` is dropped and Gemini auto-replies, **the turn boundary
is `response.done`** — that is the only thing worth waiting on.

## 8. Audio pipeline

```
mic ──▶ WAV (browser rate, maybe stereo)
          │  ffmpeg -ac 1 -ar 24000 -f s16le
          ▼
     PCM16 mono 24 kHz ──▶ base64 ──▶ input_audio_buffer.append
                                          │
     PCM16 mono 24 kHz ◀── base64 ◀── response.output_audio.delta
          │  wave.open(...) header
          ▼
        WAV ──▶ st.audio(autoplay=True)
```

| | Rate | Format |
|---|---|---|
| Upstream | 24 000 Hz | mono PCM16 LE, base64 |
| Downstream | 24 000 Hz | mono PCM16 LE, base64 |

24 kHz upstream because LiteLLM hardcodes the mime type it declares to Gemini as
`audio/pcm;rate=24000` regardless of what you send. Gemini trusts that tag, so
16 kHz audio under it is heard time-shifted. Verified by round-tripping the
model's own speech back through the mic path: clean transcription at 24000, a
dropped leading word at 16000.

The **Advanced** panel exposes 16000 for proxies on older LiteLLM versions,
which declared `rate=16000`.

## 9. Two deviations from the spec

**System instructions do not go in `session.update`.** Gemini accepts config only
in its opening `setup` frame; this proxy's LiteLLM version emits that frame
itself and drops the client's, so `instructions` is silently discarded — asking
for French replies returned English. `LiveSession._prime_instructions` instead
sends the instructions as the first conversation turn and drains the
acknowledgement before the UI sees it. Gemini keeps conversation context for the
whole session, so the effect persists across turns. `smoke_test.py` asserts this.

**Voice and temperature share that dropped frame**, so on this proxy they have no
effect: connecting with `voice: "DefinitelyNotAVoice123"` succeeds, which it
could not if the value reached Google. Both are kept under *Advanced* — they do
work against proxies that forward client session config — but labelled.

## 10. Error paths

| Failure | Surfaces as |
|---|---|
| Bad key | handshake `HTTP 401` → *"the LiteLLM key was rejected"* |
| Wrong base URL path | handshake `HTTP 404` → *"/v1/realtime not found"* |
| Key lacks model access | close `1008` with reason |
| Second `setup` reaching Gemini | close `1007 invalid argument` |
| Model silent past 90 s | `collect_turn` timeout, session stays open |
| Socket drops mid-session | `{"type":"closed"}` → UI offers reconnect |

Handshake failures are unwrapped in `_describe()`; `websockets` otherwise
reports them as a bare `InvalidStatus`.
