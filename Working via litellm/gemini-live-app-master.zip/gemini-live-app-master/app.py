"""Streamlit front-end for a live voice conversation with a Gemini Live model,
routed through a LiteLLM proxy's /v1/realtime websocket endpoint.
"""

from __future__ import annotations

import os
import queue
import time

import streamlit as st

from audio_utils import AudioError, duration_seconds, pcm16_to_wav, to_pcm16
from live_client import GEMINI_VOICES, OUTPUT_SAMPLE_RATE, LiveSession

DEFAULT_MODEL = "gemini/gemini-3.1-flash-live-preview"
DEFAULT_INSTRUCTIONS = (
    "You are a friendly voice assistant. Keep replies short and conversational, "
    "as if speaking out loud."
)
TURN_TIMEOUT_SECONDS = 120

st.set_page_config(page_title="Gemini Live · LiteLLM", page_icon="🎙️", layout="centered")


# --------------------------------------------------------------------- state


def init_state() -> None:
    st.session_state.setdefault("session", None)
    st.session_state.setdefault("messages", [])
    st.session_state.setdefault("last_recording_id", None)
    st.session_state.setdefault("status", None)


def stop_session() -> None:
    session: LiveSession | None = st.session_state.session
    if session is not None:
        session.close()
    st.session_state.session = None


def start_session(**kwargs) -> None:
    stop_session()
    try:
        session = LiveSession(**kwargs)
    except ValueError as exc:
        st.session_state.status = ("error", str(exc))
        return

    with st.spinner("Connecting to the live model and applying instructions…"):
        connected = session.start()

    if connected:
        st.session_state.session = session
        st.session_state.messages = []
        st.session_state.last_recording_id = None
        st.session_state.status = ("success", f"Connected to `{kwargs['model']}`.")
    else:
        st.session_state.session = None
        st.session_state.status = ("error", session.error or "Could not connect.")


# ---------------------------------------------------------------- turn logic


def collect_turn(session: LiveSession) -> dict:
    """Drain events until the model finishes its turn."""
    audio = bytearray()
    text: list[str] = []
    user_transcript: list[str] = []
    deadline = time.monotonic() + TURN_TIMEOUT_SECONDS

    while time.monotonic() < deadline:
        try:
            event = session.events.get(timeout=0.25)
        except queue.Empty:
            continue

        kind = event["type"]
        if kind == "audio":
            audio += event["data"]
        elif kind == "text":
            text.append(event["text"])
        elif kind == "user_transcript":
            user_transcript.append(event["text"])
        elif kind == "done":
            break
        elif kind == "error":
            return {"error": event["message"]}
        elif kind == "closed":
            return {"error": session.error or "The live session closed unexpectedly."}
    else:
        return {"error": "The model did not finish its turn in time."}

    return {
        "audio": bytes(audio),
        "text": "".join(text).strip(),
        "user_transcript": "".join(user_transcript).strip(),
    }


def run_turn(session: LiveSession, *, spoken_placeholder: str) -> None:
    """Wait for the model's reply and append both sides to the transcript."""
    with st.spinner("Gemini is thinking…"):
        result = collect_turn(session)

    if "error" in result:
        st.session_state.status = ("error", result["error"])
        return

    if spoken_placeholder and result["user_transcript"]:
        # Replace the "🎤 (voice message)" placeholder with the real transcript.
        for message in reversed(st.session_state.messages):
            if message["role"] == "user":
                message["text"] = result["user_transcript"]
                break

    st.session_state.messages.append(
        {
            "role": "assistant",
            "text": result["text"],
            "audio": result["audio"],
        }
    )


# ----------------------------------------------------------------------- UI

init_state()

st.title("🎙️ Gemini Live")
st.caption("Live voice conversation through your LiteLLM proxy.")

with st.sidebar:
    st.header("LiteLLM connection")
    base_url = st.text_input(
        "LiteLLM base URL",
        value=os.getenv("LITELLM_BASE_URL", ""),
        placeholder="https://your-proxy.example.com/litellm",
    )
    api_key = st.text_input(
        "LiteLLM API key",
        value=os.getenv("LITELLM_API_KEY", ""),
        type="password",
        placeholder="sk-…",
    )
    model = st.text_input("Model", value=os.getenv("LITELLM_MODEL", DEFAULT_MODEL))

    st.header("Behaviour")
    instructions = st.text_area("System instructions", value=DEFAULT_INSTRUCTIONS, height=110)

    with st.expander("Advanced"):
        st.caption(
            "Gemini accepts session config only in its opening `setup` frame. Some "
            "LiteLLM versions send that frame themselves and drop the client's, in "
            "which case the two settings below have no effect. (System instructions "
            "are delivered as an opening conversation turn instead, so they always "
            "apply.)"
        )
        voice = st.selectbox("Voice", GEMINI_VOICES, index=0)
        temperature = st.slider("Temperature", 0.0, 2.0, 0.8, 0.1)
        input_sample_rate = st.selectbox(
            "Microphone sample rate sent upstream",
            [24000, 16000],
            index=0,
            help=(
                "LiteLLM tags outgoing audio as `audio/pcm;rate=24000`. If the model "
                "mishears you, try 16000."
            ),
        )

    live = st.session_state.session is not None and st.session_state.session.is_alive()

    connect_col, stop_col = st.columns(2)
    if connect_col.button("Connect", type="primary", use_container_width=True, disabled=not (base_url and api_key and model)):
        start_session(
            base_url=base_url,
            api_key=api_key,
            model=model,
            instructions=instructions,
            voice=voice,
            temperature=temperature,
            input_sample_rate=input_sample_rate,
        )
        st.rerun()

    if stop_col.button("Disconnect", use_container_width=True, disabled=not live):
        stop_session()
        st.session_state.status = ("info", "Disconnected.")
        st.rerun()

    st.markdown("**Status:** " + ("🟢 live" if live else "⚪ not connected"))

if st.session_state.status:
    level, message = st.session_state.status
    getattr(st, level)(message)
    st.session_state.status = None

session: LiveSession | None = st.session_state.session

if session is None or not session.is_alive():
    if session is not None and not session.is_alive():
        st.warning("The live session ended. Reconnect from the sidebar to continue.")
    st.info(
        "Fill in your LiteLLM base URL and key in the sidebar, then press **Connect**. "
        "Once connected you can hold a spoken conversation with the model."
    )
    st.stop()

for index, message in enumerate(st.session_state.messages):
    with st.chat_message(message["role"]):
        if message["text"]:
            st.markdown(message["text"])
        elif message["role"] == "user":
            st.markdown("_🎤 voice message_")

        audio = message.get("audio")
        if audio:
            is_last = index == len(st.session_state.messages) - 1
            st.audio(
                pcm16_to_wav(audio, OUTPUT_SAMPLE_RATE),
                format="audio/wav",
                autoplay=is_last,
            )
            st.caption(f"{duration_seconds(audio, OUTPUT_SAMPLE_RATE):.1f}s of audio")

st.divider()

recording = st.audio_input("Speak, then release to send")

if recording is not None and recording.file_id != st.session_state.last_recording_id:
    st.session_state.last_recording_id = recording.file_id
    try:
        pcm = to_pcm16(recording.getvalue(), session.input_sample_rate)
    except AudioError as exc:
        st.session_state.status = ("error", str(exc))
        st.rerun()

    st.session_state.messages.append({"role": "user", "text": ""})
    session.send_audio(pcm)
    run_turn(session, spoken_placeholder="voice")
    st.rerun()

typed = st.chat_input("…or type instead")
if typed:
    st.session_state.messages.append({"role": "user", "text": typed})
    session.send_text(typed)
    run_turn(session, spoken_placeholder="")
    st.rerun()
